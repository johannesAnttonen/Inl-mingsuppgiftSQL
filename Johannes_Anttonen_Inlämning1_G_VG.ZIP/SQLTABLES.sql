DROP TABLE IF EXISTS Sales;
DROP TABLE IF EXISTS Customers;
DROP TABLE IF EXISTS Movies;
DROP TABLE IF EXISTS MovieDetails;


CREATE TABLE Customers(
--PK
id INTEGER PRIMARY KEY,
-- VALUES
account_name TEXT UNIQUE,
name TEXT,
last_name TEXT,
email TEXT,
age INTEGER
);
-- lägger till lite kunder till customers
INSERT INTO Customers(account_name,name,last_name,email,age)
VALUES("olympicsperiodic","Nima","Chandra","generator@gmail.com",23),
("bludraga","Nero","Rangluk","genrator1@gmail.com",NULL),
("trunk","Alfred","Nalliux","genara@gmail.com",32),
("Tysken","Linux","Torvaldi","gene@gmail.com",31),
("Rolandu","Rolf","Riggers","genenen@gmail.com",21),
("Riggy","Ruggy","Ruggels","gege@gmail.com",35),
("Riseup","EhMamma","ehMamma","gegege@gmail.com",29),
("Claimourthrone","Mathilda","Naxx","gegeru@gmail.com",32),
("Brokenheart","Lisa","darkness","gegegeruru@gmail.com",41),
("Ralfardar","Ralf","Rolandsson","ge321@gmail.com",64),
("BjörnBroder","Björn","Andersson","dolfdilfdalf@gmail.com",46),
("keskoo","Anita","Koivu","borkabirkafin@gmail.com",72),
("Alpho","Twurk","Yillvs","gorkdurk@gmail.com",75),
("Nils123","Nils","Andersson","duwewe@gmail.com",22),
("deathdragon","cool","unge","csgobro@gmail.com",19);

DROP TABLE IF EXISTS Director;
CREATE TABLE Director(
--PK
director_id INTEGER PRIMARY KEY,
-- VALUES
name TEXT,
last_name TEXT,
born INTEGER
);

-- DIRECTORS FÖR FILMER
INSERT INTO Director(name,last_name,born)
VALUES
-- THE DARK KNIGHT DIRECTOR
("Christopher","Nolan",1970),
-- THE GODFATHER DIRECTOR
("Francis","Coppola",1939),
-- The Shawshank Redemption DIRECTOR
("Frank","Darabont",1959),
-- LORD OF THE RINGS DIRECTOR
("Peter","Jackson",1961),
-- PULP FICTION DIRECTOR
("Quentin","Tarantino",1963);


DROP TABLE IF EXISTS MovieDetails;
CREATE TABLE MovieDetails(
-- PK
movie_info_id INTEGER PRIMARY KEY,
-- Values 
movie_name TEXT,
director_id TEXT,
star_actors TEXT,
year INTEGER,
genre TEXT,
ratings TEXT,
IMdb_rating INTEGER,
--FK
FOREIGN KEY(director_id)REFERENCES Director(director_id)
);


INSERT INTO MovieDetails(movie_name,director_id,star_actors,year,genre,ratings,IMdb_rating)
VALUES
-- DARK KNIGHT MOVIE DETAILS
("THE DARK KNIGHT",1,"Christian Bale, Heath Ledger, Aaron Eckhart",2008,"Action","PG-13",9),
-- THE GODFATHER
("THE GODFATHER",2,"Marlon Brando, Al Pacino, James Caan",1972,"Crime/Drama","R",9.2),
--The Shawshank Redemption
("The Shawshank Redemption",3,"Tim Robbins, Morgan Freeman, Bob Gunton",1994,"Drama","R",9.3),
-- LORD OF THE RINGS 
("LORD OF THE RINGS",4,"Elijah Wood, Viggo Mortensen, Ian McKellen",2003,"Action","PG-13",8.9),
-- PULP FICTION 
("PULP FICTION",5,"John Travolta, Uma Thurman, Samuel L. Jackson",1994,"Crime/Drama","R",8.9);


DROP TABLE IF EXISTS Movies;
CREATE TABLE Movies(
--PK
id INTEGER PRIMARY KEY,
--Values
name TEXT,
cost INTEGER,
movie_info_id INTEGER,
FOREIGN KEY (movie_info_id) REFERENCES MovieDetails(movie_info_id)
);


INSERT INTO Movies(name,cost,movie_info_id)
VALUES 
-- Lägger in x filmen i Movies, med Movie_info_id som kopplar den till MovieDetails
("THE DARK KNIGHT", 119, 1),
-- Lägger in x filmen i Movies, med Movie_info_id som kopplar den till MovieDetails
("THE GODFATHER", 119, 2),
-- Lägger in x filmen i Movies, med Movie_info_id som kopplar den till MovieDetails
("The Shawshank Redemption", 99, 3),
-- Lägger in x filmen i Movies, med Movie_info_id som kopplar den till MovieDetails
("LORD OF THE RINGS", 149, 4),
-- Lägger in x filmen i Movies, med Movie_info_id som kopplar den till MovieDetails
("PULP FICTION", 119, 5);


DROP TABLE IF EXISTS Sales;
CREATE TABLE Sales(
sales_id INTEGER,
-- Values
customer_id INTEGER,
movie_id INTEGER,
sales_date DATE,
quantity INTEGER,
cost INTEGER,
--PK
PRIMARY KEY(sales_id)
--FK
FOREIGN KEY(customer_id) REFERENCES Customers(id)
FOREIGN KEY(movie_id) REFERENCES Movies(id)
);

INSERT INTO Sales(customer_id,movie_id,sales_date,quantity,cost)
VALUES 


--("THE DARK KNIGHT", 119)
--("THE GODFATHER", 119
--("The Shawshank Redemption", 99
--("LORD OF THE RINGS", 149
--("PULP FICTION", 119

-- customer x köper film y datum x , är z filmer och kostar ykr
(1,2,"2020-02-03",1,119),(3,1,"2020-05-03",1,119),(6,1,"2020-02-06",2,238),
(10,5,"2020-03-03",1,119),(6,3,"2020-04-10",1,99),(11,1,"2020-02-12",1,119),
(3,1,"2020-02-13",1,119),(12,4,"2020-06-03",1,149),(2,1,"2020-04-01",1,119),
(14,5,"2020-02-03",3,359),(13,2,"2020-02-08",1,119),(9,2,"2020-04-03",2,238);

