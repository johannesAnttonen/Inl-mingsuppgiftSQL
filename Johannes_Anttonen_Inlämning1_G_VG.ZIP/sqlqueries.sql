-- Hämta alla account name från customers
SELECT account_name
FROM Customers;

-- Hämta Nimas account_name
SELECT account_name
FROM Customers
WHERE name = 'Nima';

-- hämta namn efter namn och account man på den som är 31 år
SELECT name,last_name,account_name
FROM Customers
WHERE age = 31;

-- hämta namn, efter namn och account på den som är mellan 20 och 30 år
SELECT name,last_name,account_name 
FROM Customers
WHERE age BETWEEN 20 AND 30;


-- vilken kund har betalt mest till minst
SELECT customer_id,cost
FROM Sales
ORDER BY cost DESC;

-- vilken kund har betalat minst till mest
SELECT customer_id,cost
FROM Sales
ORDER BY cost ASC;

-- DELETE (Ta bort från customers vars namn är lika med 'EhMamma' 
DELETE FROM Customers 
WHERE name ='EhMamma';

-- hitta name,last_name,account_name på den som har åldern NULL
SELECT name,last_name,account_name
FROM Customers
WHERE age IS NULL;

-- update table = customers, sätter åldern till 30 där åldern är null och id är lika 2
UPDATE Customers
SET age = 30
WHERE age IS NULL AND id = 2;

-- Kolla om det han ändrats och det har det! :D
SELECT age
FROM Customers
WHERE id = 2;

-- Olika åldrar i customers, inga dubbletter
SELECT DISTINCT age 
FROM Customers;

-- Hitta ge mig ett namn i Director som börjar på c
SELECT name
FROM Director
WHERE name LIKE 'c%';

-- ge mig ett namn i director där efternamnet slutar på o
SELECT name
FROM Director
WHERE last_name LIKE '%o';

-- Ge mig Avrage price of all products från sales där hur många kopior sålda är 1.
SELECT AVG(cost)
FROM Sales 
WHERE quantity = 1;

-- ge mig filmernas namn från movies där konstanden är 119 "kr"
SELECT name
FROM Movies 
WHERE cost LIKE 119;

-- Båda borden matchar med varandra (dom har lika innehåll)
SELECT name,movie_name
FROM Movies
INNER JOIN MovieDetails ON Movies.name = MovieDetails.movie_name;

-- left join (ger tillbaka all information som matchar mellan första bordet och andra bordet)
SELECT id 
FROM Movies
LEFT JOIN MovieDetails
ON Movies.id = MovieDetails.movie_info_id
ORDER BY Movies.id;

-- Tar bort film namn på id 1,2,3,4,5
UPDATE Movies
SET name = 'Null'
WHERE id IS 1 OR 2 OR 3 OR 4 OR 5;

-- ge mig namnen på directors som är födda efter 1950
SELECT name 
FROM Director
WHERE born > 1950;

-- ge mig namnen på directors som är födda före 1950
SELECT name
FROM Director
WHERE born < 1950;



